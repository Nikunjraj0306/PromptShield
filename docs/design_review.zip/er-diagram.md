## Single-Organization MVP and Updated Constraints

PromptShield's initial deployment serves one organization. The Organizations table and organization foreign keys are therefore omitted. Multi-tenant support would require a separate reviewed schema and authorization design.

### Authentication Constraints

Users have a unique email address within this deployment. Password hashes may be stored in a dedicated password-hash column if local password authentication is implemented; plaintext passwords and signing secrets must never be stored.

JWT expiry and validation are enforced by the backend rather than by a database relationship.

### Risk and Policy Constraints

SecurityEvents.risk_score must be an integer between 0 and 100. SecurityEvents.decision is restricted to Allow or Block. DetectionRules.weight must be a non-negative integer. Critical findings override the score threshold; otherwise, a score of at least 50 causes Block.

### Event Consistency and Retention

An event and its findings should be persisted transactionally so that partial writes are not reported as successful. If the required persistence operation fails, the request must not be forwarded.

Security events and their associated findings have a proposed 30-day retention period. Deleting an expired event must also delete its dependent findings through a documented cascade or controlled deletion transaction. Audit-log retention is separate.

### Suggested Additional Fields

- Users.password_hash: nullable only if an external identity provider is later adopted; required for application-managed password authentication.
- SecurityEvents.created_at: timestamp for event creation and retention processing.
- SecurityEvents.correlation_id: identifier for safely tracing a request across processing and diagnostics.
- DetectionRules.is_critical: indicates whether a finding from the rule must cause a Block decision.

The exact SQL data types, foreign-key deletion behavior, and constraints must be confirmed in the implementation design.
