## 12. Updated MVP Security Decisions

These decisions are proposed for faculty review and are not yet approved.

### Authentication and JWT Risks

- Store passwords only as salted hashes using an established password-hashing algorithm.
- Sign JWTs using a securely configured key; validate signature, expiry, and relevant claims.
- Keep signing keys and other secrets out of source control.
- Enforce authorization on every protected backend operation.
- Test expired, malformed, invalidly signed, and insufficiently privileged tokens.

### Critical-Rule Override

A finding from a rule marked critical causes a Block decision regardless of the numeric score. Other findings contribute configured non-negative integer weights to a score capped at 100. A score of at least 50 causes Block.

This rule must be covered by unit tests, including a critical finding with a score below 50.

### Fail-Closed Behavior

If required validation, detection, risk calculation, or policy evaluation fails, the request is not forwarded. If required event persistence fails, the request is also not forwarded. The API returns a suitable error and attempts safe diagnostic logging where possible.

Diagnostic logging must not expose credentials, tokens, or unnecessary raw request contents. The system must not claim a database write succeeded when it failed.

### Retention and Deletion

The proposed retention period for security events and associated findings is 30 days. Expired records must be removed consistently, while audit logs follow a separately defined retention policy.

Retention processing must be tested, and any approved investigation hold or applicable policy must be considered before deletion.

### Residual Risks

JWT authentication, rule-based detection, and fail-closed behavior reduce selected risks but do not guarantee that PromptShield or a protected application is secure. The implementation requires security testing, dependency review, and verification of cloud configuration.