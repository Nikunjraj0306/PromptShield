# PromptShield — Software Requirements Specification

**Project:** PromptShield  
**Version:** 0.1 — Initial Design  
**Status:** Draft for Faculty Review

## 1. Project Overview

PromptShield is a cloud-native security gateway designed to inspect HTTP requests, identify suspicious patterns, assign risk scores, apply configurable security policies, and record security events for analysis.

The initial version will use rule-based detection. It is intended as an educational security monitoring and request-control system, not a replacement for secure application development or a dedicated production-grade Web Application Firewall (WAF).

## 2. Problem Statement

Applications receive requests that may contain malicious or suspicious input. Developers need a way to inspect these requests, identify potential threats, apply consistent policies, and review security events.

PromptShield aims to demonstrate this process through a modular, cloud-deployable application with a dashboard, relational database, and documented security controls.

## 3. Project Objectives

1. Build a request-inspection API using Python and FastAPI.
2. Detect selected suspicious input patterns using modular rules.
3. Calculate a bounded risk score and explain the decision.
4. Apply configurable policies to allow or block requests in the controlled MVP.
5. Store security events and findings in Azure SQL Database.
6. Present security events and aggregate analytics in a dashboard.
7. Demonstrate cloud security, relational database design, testing, and deployment.
8. Keep the detection interface extensible for future AI/ML-based detectors.

## Authentication and Authorization

The MVP will use application-managed authentication. Passwords must be stored using a suitable salted password-hashing algorithm, never plaintext. Successful authentication will issue a signed JWT with an expiry. Protected backend endpoints must validate the token and enforce role-based permissions. Signing keys must be stored outside source control, and token revocation and refresh behavior must be documented before deployment.

Roles:
- Admin: manages users, applications, detection rules, and policies.
- Analyst: reviews events, findings, and analytics.
- Viewer: reads permitted dashboards and reports.

## Risk Scoring and Policy

Each applicable detection finding contributes a configured non-negative integer weight to the risk score.

**Risk score = minimum of 100 and the sum of applicable finding weights.**

A critical finding causes a Block decision regardless of the calculated score. Otherwise, a score of 50 or higher causes Block; a score below 50 causes Allow, subject to any additional explicitly configured policy rules. No findings produce a score of 0.

The score is a prioritization measure, not a probability that an attack will succeed. The initial weights and threshold are proposed defaults and must be tested and reviewed.

## Failure Handling

If required validation, detection, risk calculation, or policy evaluation fails, the request must not be forwarded to the demonstration target. The API returns an appropriate error response and records safe diagnostics where possible.

If the required security event cannot be persisted, the request must not be forwarded. The API must not claim that an event was successfully stored when the database write failed.

## Data Retention

The proposed retention period for security events and their associated findings is 30 days. A scheduled retention process should delete expired records consistently, subject to applicable review and any approved investigation hold. Administrative audit logs may require a separate retention policy.

## Single-Organization Scope

The MVP serves one organization. It does not implement organization or tenant management. User accounts, registered applications, endpoints, policies, events, and audit records belong to this single deployment context.

## Revised Success Criteria

- Authentication and backend role enforcement work as documented.
- Risk scores remain between 0 and 100.
- Critical findings cause Block regardless of score; other requests follow the defined threshold rule.
- Required processing failures never silently permit forwarding.
- Events and findings are persisted consistently, and persistence failure is handled safely.
- Retention behavior can be tested against the proposed 30-day period.
