## Finalized-for-Review MVP Decisions

These decisions are proposed for faculty review and are not yet approved.

### Identity and Access

The MVP uses application-managed login. Passwords are salted and hashed using an established password-hashing algorithm. JWTs are signed, time-limited, and validated by the backend. The signing key is supplied through secure configuration and is never committed to source control. Protected endpoints enforce Admin, Analyst, and Viewer permissions on the server.

### Risk Calculation

Each finding contributes a configured non-negative integer weight. The score is the sum of the applicable weights capped at 100. No findings result in a score of 0.

### Policy Evaluation

The policy engine blocks a request if any critical finding exists or the score is at least 50. Otherwise, it allows the request, subject to any additional explicitly configured policy rules. The critical-finding check takes precedence over the numeric threshold.

### Failure Behavior

Required validation, detection, risk, or policy-processing failures prevent forwarding. If the security event cannot be persisted, forwarding is also prevented. The API returns an appropriate error and records diagnostics where possible without exposing secrets or raw sensitive request data.

### Persistence and Retention

The single-organization MVP omits the Organizations table. The proposed retention period for security events and associated findings is 30 days. Expired event and finding records must be deleted consistently; administrative audit-log retention is defined separately.

### Deployment Security

Use HTTPS in deployment, restricted database access, parameterized queries, least-privilege identities, secure secret configuration, request-size limits, and rate limiting. Configure managed identity and Key Vault where supported. Deployment settings must be verified before claiming these controls are active.
